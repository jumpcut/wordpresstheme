Hexo
===

A Typography enriched, modern minimal theme. It is retina-ready responsive theme, with emphasis on user readability to make sure that your content is the king. Ample of white-spaces allow website visitors to rest their eyes while reading. It has two widget areas and a nice collapsible menu. 

#Features:

##Widget areas:
1. Footer
2. Top

##Customizer
1. Custom Header
2. Custom background

##Post Formats:
Aside and Standard.

##Featured images
Post and Pages can have featured images.
